import { Routes, Route, Navigate } from 'react-router-dom'
import { AuthProvider, useAuth } from './context/AuthContext'
import Login from './pages/Login'
import Register from './pages/Register'
import Dashboard from './pages/Dashboard'
import BookAppointment from './pages/BookAppointment'
import MyAppointments from './pages/MyAppointments'
import EMRList from './pages/EMRList'
import CreateEMR from './pages/CreateEMR'
import Navbar from './components/Navbar'

function PrivateRoute({ children, roles }) {
  const { user } = useAuth()
  if (!user) return <Navigate to="/login" />
  if (roles && !roles.includes(user.role)) return <Navigate to="/dashboard" />
  return children
}

export default function App() {
  return (
    <AuthProvider>
      <Navbar />
      <Routes>
        <Route path="/" element={<Navigate to="/dashboard" />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/dashboard" element={<PrivateRoute><Dashboard /></PrivateRoute>} />
        <Route path="/appointments/book" element={<PrivateRoute roles={['PATIENT']}><BookAppointment /></PrivateRoute>} />
        <Route path="/appointments" element={<PrivateRoute><MyAppointments /></PrivateRoute>} />
        <Route path="/emr" element={<PrivateRoute roles={['DOCTOR','RECEPTIONIST']}><EMRList /></PrivateRoute>} />
        <Route path="/emr/new" element={<PrivateRoute roles={['DOCTOR']}><CreateEMR /></PrivateRoute>} />
      </Routes>
    </AuthProvider>
  )
}
