import { useAuth } from '../context/AuthContext'
import { Link } from 'react-router-dom'
import Card from '../components/Card'

const roleColor = { PATIENT: '#2e7d32', DOCTOR: '#0057A8', RECEPTIONIST: '#6a1b9a' }

export default function Dashboard() {
  const { user } = useAuth()
  if (!user) return null

  const cards = {
    PATIENT: [
      { title: 'Book Appointment', desc: 'Schedule a visit with a doctor', link: '/appointments/book', icon: '📅' },
      { title: 'My Appointments', desc: 'View your upcoming & past appointments', link: '/appointments', icon: '🗓️' },
    ],
    DOCTOR: [
      { title: 'My Schedule', desc: 'View your appointments', link: '/appointments', icon: '🗓️' },
      { title: 'EMR Records', desc: 'View & create patient records', link: '/emr', icon: '📋' },
      { title: 'New EMR', desc: 'Create a new medical record', link: '/emr/new', icon: '✏️' },
    ],
    RECEPTIONIST: [
      { title: 'All Appointments', desc: 'Manage all clinic appointments', link: '/appointments', icon: '📅' },
      { title: 'EMR Records', desc: 'Access patient medical records', link: '/emr', icon: '📋' },
    ]
  }

  return (
    <div style={{ maxWidth: 900, margin: '40px auto', padding: '0 20px' }}>
      <div style={{ marginBottom: 32 }}>
        <h1 style={{ fontSize: 28, fontWeight: 700 }}>Welcome, {user.name}</h1>
        <span style={{
          display:'inline-block', marginTop:8, padding:'4px 12px', borderRadius:20,
          background: roleColor[user.role] + '18', color: roleColor[user.role],
          fontWeight: 600, fontSize: 13
        }}>{user.role}</span>
      </div>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(260px, 1fr))', gap:20 }}>
        {(cards[user.role] || []).map(c => (
          <Link key={c.link} to={c.link}>
            <Card style={{ cursor:'pointer', transition:'transform 0.2s, box-shadow 0.2s',
              ':hover':{ transform:'translateY(-2px)' } }}>
              <div style={{ fontSize:36, marginBottom:12 }}>{c.icon}</div>
              <h3 style={{ marginBottom:6, color:'#0057A8' }}>{c.title}</h3>
              <p style={{ color:'#666', fontSize:14 }}>{c.desc}</p>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  )
}
