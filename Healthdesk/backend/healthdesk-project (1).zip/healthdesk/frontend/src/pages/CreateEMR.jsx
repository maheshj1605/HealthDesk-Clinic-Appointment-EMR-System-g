import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { userAPI, emrAPI } from '../services/api'
import Card from '../components/Card'
import Button from '../components/Button'

export default function CreateEMR() {
  const [patients, setPatients] = useState([])
  const [form, setForm] = useState({ patientId:'', appointmentId:'1', diagnosis:'', prescription:'', notes:'' })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const navigate = useNavigate()

  useEffect(() => { userAPI.getPatients().then(r => setPatients(r.data)).catch(()=>{}) }, [])

  const handleSubmit = async (e) => {
    e.preventDefault(); setLoading(true); setError('')
    try {
      await emrAPI.create({ ...form, patientId: parseInt(form.patientId), appointmentId: parseInt(form.appointmentId) })
      navigate('/emr')
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to create EMR')
    } finally { setLoading(false) }
  }

  return (
    <div style={{ maxWidth:560, margin:'40px auto', padding:'0 20px' }}>
      <Card>
        <h2 style={{ marginBottom:24, color:'#0057A8' }}>New EMR Record</h2>
        {error && <p style={{ color:'#e53935', marginBottom:12, fontSize:14 }}>{error}</p>}
        <form onSubmit={handleSubmit} style={{ display:'flex', flexDirection:'column', gap:16 }}>
          <select value={form.patientId} onChange={e=>setForm({...form,patientId:e.target.value})} required>
            <option value="">Select Patient</option>
            {patients.map(p=><option key={p.id} value={p.id}>{p.name}</option>)}
          </select>
          <textarea placeholder="Diagnosis" rows={3} value={form.diagnosis}
            onChange={e=>setForm({...form,diagnosis:e.target.value})}
            style={{ padding:'10px 14px',border:'1.5px solid #d0d9e8',borderRadius:8,fontFamily:'inherit',fontSize:14,resize:'vertical' }} />
          <textarea placeholder="Prescription (Rx)" rows={4} value={form.prescription}
            onChange={e=>setForm({...form,prescription:e.target.value})}
            style={{ padding:'10px 14px',border:'1.5px solid #d0d9e8',borderRadius:8,fontFamily:'inherit',fontSize:14,resize:'vertical' }} />
          <textarea placeholder="Additional notes" rows={3} value={form.notes}
            onChange={e=>setForm({...form,notes:e.target.value})}
            style={{ padding:'10px 14px',border:'1.5px solid #d0d9e8',borderRadius:8,fontFamily:'inherit',fontSize:14,resize:'vertical' }} />
          <Button type="submit" disabled={loading}>{loading ? 'Saving...' : 'Create EMR Record'}</Button>
        </form>
      </Card>
    </div>
  )
}
