import { useState, useEffect } from 'react'
import { userAPI, emrAPI } from '../services/api'
import Card from '../components/Card'
import Button from '../components/Button'
import { Link } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

export default function EMRList() {
  const { user } = useAuth()
  const [patients, setPatients] = useState([])
  const [selectedPatient, setSelectedPatient] = useState(null)
  const [records, setRecords] = useState([])
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    userAPI.getPatients().then(r => setPatients(r.data)).catch(() => {})
  }, [])

  const loadRecords = (patientId) => {
    setSelectedPatient(patientId); setLoading(true)
    emrAPI.getByPatient(patientId).then(r => setRecords(r.data)).finally(() => setLoading(false))
  }

  const downloadPdf = async (id) => {
    const { data } = await emrAPI.downloadPdf(id)
    const url = URL.createObjectURL(new Blob([data], { type: 'application/pdf' }))
    const a = document.createElement('a'); a.href = url
    a.download = `prescription_${id}.pdf`; a.click()
    URL.revokeObjectURL(url)
  }

  return (
    <div style={{ maxWidth:900, margin:'40px auto', padding:'0 20px' }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:24 }}>
        <h2 style={{ color:'#0057A8' }}>EMR Records</h2>
        {user.role === 'DOCTOR' && <Link to="/emr/new"><Button>+ New Record</Button></Link>}
      </div>
      <Card style={{ marginBottom:20 }}>
        <label style={{ fontSize:13, color:'#666', display:'block', marginBottom:8 }}>Select Patient</label>
        <select onChange={e=>loadRecords(e.target.value)} defaultValue="">
          <option value="" disabled>Choose a patient...</option>
          {patients.map(p => <option key={p.id} value={p.id}>{p.name} — {p.email}</option>)}
        </select>
      </Card>
      {loading && <p style={{ textAlign:'center', color:'#666' }}>Loading records...</p>}
      {!loading && selectedPatient && records.length === 0 && (
        <Card><p style={{ color:'#666', textAlign:'center' }}>No EMR records for this patient.</p></Card>
      )}
      <div style={{ display:'flex', flexDirection:'column', gap:16 }}>
        {records.map(r => (
          <Card key={r.id}>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', flexWrap:'wrap', gap:12 }}>
              <div>
                <p style={{ fontWeight:600, marginBottom:4 }}>Visit: {r.visitDate} · Dr. {r.doctor?.name}</p>
                {r.diagnosis && <p style={{ fontSize:13, marginBottom:4 }}><strong>Diagnosis:</strong> {r.diagnosis}</p>}
                {r.prescription && <p style={{ fontSize:13, marginBottom:4 }}><strong>Rx:</strong> {r.prescription}</p>}
                {r.notes && <p style={{ fontSize:13, color:'#888' }}>{r.notes}</p>}
              </div>
              <Button variant="secondary" style={{ fontSize:12 }} onClick={() => downloadPdf(r.id)}>
                📄 Download PDF
              </Button>
            </div>
          </Card>
        ))}
      </div>
    </div>
  )
}
