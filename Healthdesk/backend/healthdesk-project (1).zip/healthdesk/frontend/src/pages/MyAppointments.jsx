import { useState, useEffect } from 'react'
import { useAuth } from '../context/AuthContext'
import { appointmentAPI } from '../services/api'
import Card from '../components/Card'
import Button from '../components/Button'

const statusColor = { SCHEDULED:'#0057A8', COMPLETED:'#2e7d32', CANCELLED:'#e53935' }

export default function MyAppointments() {
  const { user } = useAuth()
  const [appointments, setAppointments] = useState([])
  const [loading, setLoading] = useState(true)

  const fetchData = () => {
    const fn = user.role === 'RECEPTIONIST' ? appointmentAPI.getAll : appointmentAPI.getMine
    fn().then(r => setAppointments(r.data)).finally(() => setLoading(false))
  }

  useEffect(() => { fetchData() }, [])

  const updateStatus = async (id, status) => {
    await appointmentAPI.updateStatus(id, status)
    fetchData()
  }

  if (loading) return <div style={{ padding:40, textAlign:'center' }}>Loading...</div>

  return (
    <div style={{ maxWidth:900, margin:'40px auto', padding:'0 20px' }}>
      <h2 style={{ marginBottom:24, color:'#0057A8' }}>
        {user.role === 'RECEPTIONIST' ? 'All Appointments' : 'My Appointments'}
      </h2>
      {appointments.length === 0 ? (
        <Card><p style={{ color:'#666', textAlign:'center' }}>No appointments found.</p></Card>
      ) : (
        <div style={{ display:'flex', flexDirection:'column', gap:16 }}>
          {appointments.map(a => (
            <Card key={a.id} style={{ display:'flex', justifyContent:'space-between', alignItems:'center', flexWrap:'wrap', gap:12 }}>
              <div>
                <p style={{ fontWeight:600 }}>
                  {user.role === 'PATIENT' ? `Dr. ${a.doctor?.name}` : a.patient?.name}
                </p>
                <p style={{ fontSize:13, color:'#666', marginTop:4 }}>
                  {new Date(a.appointmentTime).toLocaleString()}
                </p>
                {a.notes && <p style={{ fontSize:13, color:'#888', marginTop:2 }}>{a.notes}</p>}
              </div>
              <div style={{ display:'flex', gap:8, alignItems:'center' }}>
                <span style={{
                  padding:'4px 10px', borderRadius:20, fontSize:12, fontWeight:600,
                  background: statusColor[a.status] + '18', color: statusColor[a.status]
                }}>{a.status}</span>
                {(user.role === 'DOCTOR' || user.role === 'RECEPTIONIST') && a.status === 'SCHEDULED' && (
                  <>
                    <Button variant="secondary" style={{ fontSize:12, padding:'6px 12px' }}
                      onClick={() => updateStatus(a.id, 'COMPLETED')}>Complete</Button>
                    <Button variant="danger" style={{ fontSize:12, padding:'6px 12px' }}
                      onClick={() => updateStatus(a.id, 'CANCELLED')}>Cancel</Button>
                  </>
                )}
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
