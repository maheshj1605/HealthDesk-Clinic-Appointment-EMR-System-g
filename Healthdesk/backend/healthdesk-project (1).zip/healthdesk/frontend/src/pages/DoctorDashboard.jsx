import { useState, useEffect } from 'react'
import Navbar from '../components/shared/Navbar'
import { appointmentAPI, emrAPI } from '../services/api'
import { useAuth } from '../context/AuthContext'
import toast from 'react-hot-toast'
import { format } from 'date-fns'
import { FileText, CheckCircle } from 'lucide-react'

const STATUS_COLOR = {
  PENDING: 'bg-yellow-100 text-yellow-800',
  CONFIRMED: 'bg-blue-100 text-blue-800',
  COMPLETED: 'bg-green-100 text-green-800',
  CANCELLED: 'bg-red-100 text-red-800',
}

export default function DoctorDashboard() {
  const { user } = useAuth()
  const [appointments, setAppointments] = useState([])
  const [tab, setTab] = useState('today')
  const [selected, setSelected] = useState(null)
  const [emrForm, setEmrForm] = useState({ diagnosis:'', prescription:'', symptoms:'', notes:'', labResults:'' })
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    appointmentAPI.getMy().then(r => setAppointments(r.data)).catch(() => {})
  }, [])

  const today = appointments.filter(a => {
    if (!a.appointmentTime) return false
    return new Date(a.appointmentTime).toDateString() === new Date().toDateString()
  })

  const updateStatus = async (id, status) => {
    try {
      const res = await appointmentAPI.updateStatus(id, status)
      setAppointments(apps => apps.map(a => a.id === id ? res.data : a))
      toast.success('Status updated')
    } catch { toast.error('Update failed') }
  }

  const submitEmr = async (e) => {
    e.preventDefault()
    if (!selected) return
    setLoading(true)
    try {
      await emrAPI.create({ ...emrForm, patientId: selected.patient.id, appointmentId: selected.id })
      await updateStatus(selected.id, 'COMPLETED')
      toast.success('EMR saved & appointment completed!')
      setSelected(null)
      setEmrForm({ diagnosis:'', prescription:'', symptoms:'', notes:'', labResults:'' })
    } catch { toast.error('Failed to save EMR') } finally { setLoading(false) }
  }

  const displayed = tab === 'today' ? today : appointments

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="max-w-5xl mx-auto p-6">
        <h1 className="text-2xl font-bold text-gray-800 mb-6">Doctor Dashboard</h1>
        <div className="flex gap-2 mb-6">
          {[['today',"Today's Appointments"],['all','All Appointments']].map(([v,l]) => (
            <button key={v} onClick={() => setTab(v)}
              className={`px-4 py-2 rounded-lg text-sm font-medium ${tab===v ? 'bg-blue-600 text-white' : 'bg-white text-gray-600 border hover:bg-gray-50'}`}>
              {l}
            </button>
          ))}
        </div>

        <div className="grid lg:grid-cols-2 gap-4">
          <div className="space-y-3">
            {displayed.length === 0 && <p className="text-gray-500 text-sm">No appointments.</p>}
            {displayed.map(a => (
              <div key={a.id} onClick={() => setSelected(a)}
                className={`bg-white rounded-xl p-4 shadow-sm border cursor-pointer hover:border-blue-300 transition-colors ${selected?.id===a.id ? 'border-blue-500' : ''}`}>
                <div className="flex justify-between items-start">
                  <div>
                    <p className="font-medium text-sm text-gray-800">{a.patient?.fullName}</p>
                    <p className="text-xs text-gray-500">{a.appointmentTime ? format(new Date(a.appointmentTime), 'dd MMM yyyy, h:mm a') : ''}</p>
                    {a.reason && <p className="text-xs text-gray-400 mt-0.5">{a.reason}</p>}
                  </div>
                  <span className={`text-xs font-semibold px-2 py-1 rounded-full ${STATUS_COLOR[a.status] || ''}`}>{a.status}</span>
                </div>
                {a.status === 'PENDING' && (
                  <div className="flex gap-2 mt-3">
                    <button onClick={(e) => {e.stopPropagation(); updateStatus(a.id,'CONFIRMED')}}
                      className="text-xs bg-blue-50 text-blue-700 px-2 py-1 rounded hover:bg-blue-100">Confirm</button>
                    <button onClick={(e) => {e.stopPropagation(); updateStatus(a.id,'CANCELLED')}}
                      className="text-xs bg-red-50 text-red-700 px-2 py-1 rounded hover:bg-red-100">Cancel</button>
                  </div>
                )}
              </div>
            ))}
          </div>

          {selected && selected.status !== 'COMPLETED' && (
            <div className="bg-white rounded-xl p-5 shadow-sm border h-fit">
              <h3 className="font-semibold text-gray-800 mb-3 flex items-center gap-2">
                <FileText size={16} className="text-blue-600" />
                Write EMR — {selected.patient?.fullName}
              </h3>
              <form onSubmit={submitEmr} className="space-y-3">
                {[
                  ['symptoms','Symptoms','Enter symptoms...'],
                  ['diagnosis','Diagnosis *','Diagnosis...'],
                  ['prescription','Prescription','Medications & dosage...'],
                  ['labResults','Lab Results','Enter lab results...'],
                  ['notes','Doctor Notes','Additional notes...'],
                ].map(([key, label, ph]) => (
                  <div key={key}>
                    <label className="block text-xs font-medium text-gray-700 mb-1">{label}</label>
                    <textarea required={key==='diagnosis'} rows={key==='prescription'?3:2}
                      value={emrForm[key]} placeholder={ph}
                      onChange={e => setEmrForm({...emrForm, [key]: e.target.value})}
                      className="w-full border rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none" />
                  </div>
                ))}
                <button type="submit" disabled={loading}
                  className="w-full flex items-center justify-center gap-2 bg-green-600 text-white py-2 rounded-lg text-sm font-medium hover:bg-green-700 disabled:opacity-50">
                  <CheckCircle size={15} /> {loading ? 'Saving...' : 'Save EMR & Complete'}
                </button>
              </form>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
