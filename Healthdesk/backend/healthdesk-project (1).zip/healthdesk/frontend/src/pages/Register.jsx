import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { authAPI } from '../services/api'
import { useAuth } from '../context/AuthContext'
import Card from '../components/Card'
import Button from '../components/Button'

export default function Register() {
  const [form, setForm] = useState({ name:'', email:'', password:'', role:'PATIENT', phone:'', specialization:'' })
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const { login } = useAuth()
  const navigate = useNavigate()

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true); setError('')
    try {
      const { data } = await authAPI.register(form)
      login(data); navigate('/dashboard')
    } catch (err) {
      setError(err.response?.data?.message || 'Registration failed')
    } finally { setLoading(false) }
  }

  return (
    <div style={{ display:'flex', justifyContent:'center', alignItems:'center', minHeight:'calc(100vh - 60px)', padding: 20 }}>
      <Card style={{ width: 440 }}>
        <h2 style={{ marginBottom: 24, color: '#0057A8' }}>Create Account</h2>
        {error && <p style={{ color:'#e53935', marginBottom:12, fontSize:14 }}>{error}</p>}
        <form onSubmit={handleSubmit} style={{ display:'flex', flexDirection:'column', gap:14 }}>
          <input placeholder="Full Name" value={form.name} onChange={e=>setForm({...form,name:e.target.value})} required />
          <input type="email" placeholder="Email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})} required />
          <input type="password" placeholder="Password (min 6 chars)" value={form.password} onChange={e=>setForm({...form,password:e.target.value})} required />
          <input placeholder="Phone" value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})} />
          <select value={form.role} onChange={e=>setForm({...form,role:e.target.value})}>
            <option value="PATIENT">Patient</option>
            <option value="DOCTOR">Doctor</option>
            <option value="RECEPTIONIST">Receptionist</option>
          </select>
          {form.role === 'DOCTOR' && (
            <input placeholder="Specialization (e.g., Cardiologist)" value={form.specialization} onChange={e=>setForm({...form,specialization:e.target.value})} />
          )}
          <Button type="submit" disabled={loading}>{loading ? 'Registering...' : 'Create Account'}</Button>
        </form>
        <p style={{ marginTop:16, fontSize:14, textAlign:'center' }}>
          Already have an account? <Link to="/login" style={{ color:'#0057A8' }}>Sign In</Link>
        </p>
      </Card>
    </div>
  )
}
