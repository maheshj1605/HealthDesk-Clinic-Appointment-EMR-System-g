import { useState, useEffect } from 'react'
import Navbar from '../components/shared/Navbar'
import { appointmentAPI } from '../services/api'
import toast from 'react-hot-toast'
import { format, startOfDay, endOfDay } from 'date-fns'
import { Search, Users } from 'lucide-react'

const STATUS_COLOR = {
  PENDING: 'bg-yellow-100 text-yellow-800',
  CONFIRMED: 'bg-blue-100 text-blue-800',
  COMPLETED: 'bg-green-100 text-green-800',
  CANCELLED: 'bg-red-100 text-red-800',
}

export default function ReceptionistDashboard() {
  const [appointments, setAppointments] = useState([])
  const [date, setDate] = useState(new Date().toISOString().slice(0,10))
  const [search, setSearch] = useState('')

  const load = async (d) => {
    try {
      const start = startOfDay(new Date(d)).toISOString()
      const end = endOfDay(new Date(d)).toISOString()
      const res = await appointmentAPI.getByRange(start, end)
      setAppointments(res.data)
    } catch { toast.error('Failed to load appointments') }
  }

  useEffect(() => { load(date) }, [date])

  const updateStatus = async (id, status) => {
    try {
      const res = await appointmentAPI.updateStatus(id, status)
      setAppointments(apps => apps.map(a => a.id === id ? res.data : a))
      toast.success('Updated')
    } catch { toast.error('Failed') }
  }

  const filtered = appointments.filter(a =>
    !search ||
    a.patient?.fullName?.toLowerCase().includes(search.toLowerCase()) ||
    a.doctor?.fullName?.toLowerCase().includes(search.toLowerCase())
  )

  const stats = {
    total: appointments.length,
    pending: appointments.filter(a => a.status === 'PENDING').length,
    confirmed: appointments.filter(a => a.status === 'CONFIRMED').length,
    completed: appointments.filter(a => a.status === 'COMPLETED').length,
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="max-w-5xl mx-auto p-6">
        <h1 className="text-2xl font-bold text-gray-800 mb-6">Reception Dashboard</h1>

        <div className="grid grid-cols-4 gap-3 mb-6">
          {[['Total', stats.total, 'bg-blue-500'],['Pending', stats.pending, 'bg-yellow-500'],
            ['Confirmed', stats.confirmed, 'bg-indigo-500'],['Completed', stats.completed, 'bg-green-500']].map(([l,v,c]) => (
            <div key={l} className="bg-white rounded-xl p-4 shadow-sm border text-center">
              <div className={`text-2xl font-bold text-white ${c} rounded-lg w-10 h-10 flex items-center justify-center mx-auto mb-1`}>{v}</div>
              <p className="text-xs text-gray-500 font-medium">{l}</p>
            </div>
          ))}
        </div>

        <div className="flex gap-3 mb-4">
          <input type="date" value={date} onChange={e => setDate(e.target.value)}
            className="border rounded-lg px-3 py-2 text-sm" />
          <div className="relative flex-1">
            <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input placeholder="Search patient or doctor..."
              value={search} onChange={e => setSearch(e.target.value)}
              className="w-full border rounded-lg pl-9 pr-3 py-2 text-sm" />
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b">
              <tr>
                {['Patient','Doctor','Time','Reason','Status','Actions'].map(h => (
                  <th key={h} className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {filtered.length === 0 && (
                <tr><td colSpan={6} className="text-center py-8 text-gray-400">No appointments found</td></tr>
              )}
              {filtered.map(a => (
                <tr key={a.id} className="hover:bg-gray-50">
                  <td className="px-4 py-3 font-medium text-gray-800">{a.patient?.fullName}</td>
                  <td className="px-4 py-3 text-gray-600">Dr. {a.doctor?.fullName}</td>
                  <td className="px-4 py-3 text-gray-600 text-xs">{a.appointmentTime ? format(new Date(a.appointmentTime), 'h:mm a') : ''}</td>
                  <td className="px-4 py-3 text-gray-500 text-xs max-w-xs truncate">{a.reason || '-'}</td>
                  <td className="px-4 py-3">
                    <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${STATUS_COLOR[a.status] || ''}`}>{a.status}</span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex gap-1">
                      {a.status === 'PENDING' && (
                        <button onClick={() => updateStatus(a.id,'CONFIRMED')}
                          className="text-xs bg-blue-50 text-blue-700 px-2 py-1 rounded hover:bg-blue-100">Confirm</button>
                      )}
                      {a.status !== 'CANCELLED' && a.status !== 'COMPLETED' && (
                        <button onClick={() => updateStatus(a.id,'CANCELLED')}
                          className="text-xs bg-red-50 text-red-700 px-2 py-1 rounded hover:bg-red-100">Cancel</button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
