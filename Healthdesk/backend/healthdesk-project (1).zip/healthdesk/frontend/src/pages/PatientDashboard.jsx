import { useState, useEffect } from 'react'
import Navbar from '../components/shared/Navbar'
import { appointmentAPI, emrAPI } from '../services/api'
import { useAuth } from '../context/AuthContext'
import toast from 'react-hot-toast'
import { Calendar, FileText, Plus } from 'lucide-react'
import { format } from 'date-fns'

const STATUS_COLOR = {
  PENDING: 'bg-yellow-100 text-yellow-800',
  CONFIRMED: 'bg-blue-100 text-blue-800',
  COMPLETED: 'bg-green-100 text-green-800',
  CANCELLED: 'bg-red-100 text-red-800',
}

export default function PatientDashboard() {
  const { user } = useAuth()
  const [tab, setTab] = useState('appointments')
  const [appointments, setAppointments] = useState([])
  const [emrs, setEmrs] = useState([])
  const [doctors, setDoctors] = useState([])
  const [showBook, setShowBook] = useState(false)
  const [form, setForm] = useState({ doctorId: '', appointmentTime: '', reason: '' })
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    appointmentAPI.getMy().then(r => setAppointments(r.data)).catch(() => {})
    emrAPI.getHistory(user.userId).then(r => setEmrs(r.data)).catch(() => {})
    appointmentAPI.getDoctors().then(r => setDoctors(r.data)).catch(() => {})
  }, [user.userId])

  const bookAppointment = async (e) => {
    e.preventDefault()
    setLoading(true)
    try {
      const res = await appointmentAPI.book({ ...form, appointmentTime: new Date(form.appointmentTime).toISOString() })
      setAppointments([res.data, ...appointments])
      setShowBook(false)
      toast.success('Appointment booked!')
    } catch (err) {
      toast.error(err.response?.data?.message || 'Booking failed')
    } finally {
      setLoading(false)
    }
  }

  const downloadPdf = async (emrId) => {
    try {
      const res = await emrAPI.downloadPdf(emrId)
      const url = window.URL.createObjectURL(new Blob([res.data]))
      const a = document.createElement('a'); a.href = url
      a.download = `prescription-${emrId}.pdf`; a.click()
    } catch { toast.error('Download failed') }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="max-w-4xl mx-auto p-6">
        <h1 className="text-2xl font-bold text-gray-800 mb-6">Patient Dashboard</h1>
        <div className="flex gap-2 mb-6">
          {['appointments','records'].map(t => (
            <button key={t} onClick={() => setTab(t)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${tab===t ? 'bg-blue-600 text-white' : 'bg-white text-gray-600 border hover:bg-gray-50'}`}>
              {t === 'appointments' ? 'My Appointments' : 'Medical Records'}
            </button>
          ))}
        </div>

        {tab === 'appointments' && (
          <div>
            <button onClick={() => setShowBook(!showBook)}
              className="mb-4 flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-700">
              <Plus size={16} /> Book Appointment
            </button>

            {showBook && (
              <form onSubmit={bookAppointment} className="bg-white rounded-xl p-5 shadow-sm border mb-4 grid gap-3">
                <h3 className="font-semibold text-gray-800">New Appointment</h3>
                <select required value={form.doctorId} onChange={e => setForm({...form, doctorId: e.target.value})}
                  className="border rounded-lg px-3 py-2 text-sm">
                  <option value="">Select Doctor</option>
                  {doctors.map(d => <option key={d.id} value={d.id}>Dr. {d.fullName} {d.specialization ? `— ${d.specialization}` : ''}</option>)}
                </select>
                <input type="datetime-local" required value={form.appointmentTime}
                  onChange={e => setForm({...form, appointmentTime: e.target.value})}
                  className="border rounded-lg px-3 py-2 text-sm" />
                <input placeholder="Reason for visit" value={form.reason}
                  onChange={e => setForm({...form, reason: e.target.value})}
                  className="border rounded-lg px-3 py-2 text-sm" />
                <div className="flex gap-2">
                  <button type="submit" disabled={loading}
                    className="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium disabled:opacity-50">
                    {loading ? 'Booking...' : 'Book'}
                  </button>
                  <button type="button" onClick={() => setShowBook(false)}
                    className="bg-gray-100 text-gray-700 px-4 py-2 rounded-lg text-sm">Cancel</button>
                </div>
              </form>
            )}

            <div className="space-y-3">
              {appointments.length === 0 && <p className="text-gray-500 text-sm">No appointments yet.</p>}
              {appointments.map(a => (
                <div key={a.id} className="bg-white rounded-xl p-4 shadow-sm border flex justify-between items-start">
                  <div>
                    <div className="flex items-center gap-2">
                      <Calendar size={15} className="text-blue-500" />
                      <span className="font-medium text-sm text-gray-800">
                        Dr. {a.doctor?.fullName}
                      </span>
                    </div>
                    <p className="text-xs text-gray-500 mt-1">
                      {a.appointmentTime ? format(new Date(a.appointmentTime), 'dd MMM yyyy, h:mm a') : ''}
                    </p>
                    {a.reason && <p className="text-xs text-gray-500">{a.reason}</p>}
                  </div>
                  <span className={`text-xs font-semibold px-2 py-1 rounded-full ${STATUS_COLOR[a.status] || ''}`}>{a.status}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {tab === 'records' && (
          <div className="space-y-3">
            {emrs.length === 0 && <p className="text-gray-500 text-sm">No medical records yet.</p>}
            {emrs.map(e => (
              <div key={e.id} className="bg-white rounded-xl p-4 shadow-sm border">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <p className="font-medium text-gray-800 text-sm">Dr. {e.doctor?.fullName}</p>
                    <p className="text-xs text-gray-500">{e.visitDate}</p>
                  </div>
                  <button onClick={() => downloadPdf(e.id)}
                    className="flex items-center gap-1 text-xs text-blue-600 hover:underline">
                    <FileText size={13} /> PDF
                  </button>
                </div>
                <p className="text-sm text-gray-700"><span className="font-medium">Diagnosis:</span> {e.diagnosis}</p>
                {e.prescription && <p className="text-sm text-gray-700 mt-1"><span className="font-medium">Prescription:</span> {e.prescription}</p>}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
