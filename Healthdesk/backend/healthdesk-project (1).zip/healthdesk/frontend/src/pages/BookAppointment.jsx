import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { userAPI, appointmentAPI } from '../services/api'
import Card from '../components/Card'
import Button from '../components/Button'

export default function BookAppointment() {
  const [doctors, setDoctors] = useState([])
  const [form, setForm] = useState({ doctorId: '', appointmentTime: '', notes: '' })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const navigate = useNavigate()

  useEffect(() => {
    userAPI.getDoctors().then(r => setDoctors(r.data)).catch(() => {})
  }, [])

  const handleSubmit = async (e) => {
    e.preventDefault(); setLoading(true); setError('')
    try {
      await appointmentAPI.book({
        doctorId: parseInt(form.doctorId),
        appointmentTime: form.appointmentTime,
        notes: form.notes
      })
      navigate('/appointments')
    } catch (err) {
      setError(err.response?.data?.message || 'Booking failed')
    } finally { setLoading(false) }
  }

  return (
    <div style={{ maxWidth:500, margin:'40px auto', padding:'0 20px' }}>
      <Card>
        <h2 style={{ marginBottom:24, color:'#0057A8' }}>Book Appointment</h2>
        {error && <p style={{ color:'#e53935', marginBottom:12, fontSize:14 }}>{error}</p>}
        <form onSubmit={handleSubmit} style={{ display:'flex', flexDirection:'column', gap:16 }}>
          <select value={form.doctorId} onChange={e=>setForm({...form,doctorId:e.target.value})} required>
            <option value="">Select a Doctor</option>
            {doctors.map(d => (
              <option key={d.id} value={d.id}>
                Dr. {d.name} — {d.specialization || 'General'}
              </option>
            ))}
          </select>
          <div>
            <label style={{ fontSize:13, color:'#666', display:'block', marginBottom:6 }}>Appointment Date & Time</label>
            <input type="datetime-local" value={form.appointmentTime}
              onChange={e=>setForm({...form,appointmentTime:e.target.value})} required />
          </div>
          <textarea placeholder="Notes / Reason for visit (optional)" rows={3}
            value={form.notes} onChange={e=>setForm({...form,notes:e.target.value})}
            style={{ padding:'10px 14px', border:'1.5px solid #d0d9e8', borderRadius:8, fontFamily:'inherit', fontSize:14, resize:'vertical' }}
          />
          <Button type="submit" disabled={loading}>{loading ? 'Booking...' : 'Confirm Appointment'}</Button>
        </form>
      </Card>
    </div>
  )
}
