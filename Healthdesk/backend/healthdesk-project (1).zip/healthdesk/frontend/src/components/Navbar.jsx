import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

export default function Navbar() {
  const { user, logout } = useAuth()
  const navigate = useNavigate()

  const handleLogout = () => { logout(); navigate('/login') }

  return (
    <nav style={{
      background: '#0057A8', color: '#fff', padding: '0 24px',
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      height: 60, boxShadow: '0 2px 8px rgba(0,0,0,0.15)'
    }}>
      <Link to="/dashboard" style={{ fontWeight: 700, fontSize: 20, color: '#fff' }}>
        HealthDesk
      </Link>
      {user && (
        <div style={{ display: 'flex', gap: 20, alignItems: 'center', fontSize: 14 }}>
          <Link to="/dashboard" style={{ color: '#fff' }}>Dashboard</Link>
          <Link to="/appointments" style={{ color: '#fff' }}>Appointments</Link>
          {user.role === 'PATIENT' && <Link to="/appointments/book" style={{ color: '#fff' }}>Book</Link>}
          {(user.role === 'DOCTOR' || user.role === 'RECEPTIONIST') && (
            <Link to="/emr" style={{ color: '#fff' }}>EMR</Link>
          )}
          <span style={{ opacity: 0.8 }}>{user.name} ({user.role})</span>
          <button onClick={handleLogout} style={{
            background: 'rgba(255,255,255,0.2)', border: 'none', color: '#fff',
            padding: '6px 14px', borderRadius: 6, cursor: 'pointer'
          }}>Logout</button>
        </div>
      )}
    </nav>
  )
}
