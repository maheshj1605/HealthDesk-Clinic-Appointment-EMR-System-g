export default function Button({ children, variant = 'primary', style = {}, ...props }) {
  const base = {
    padding: '10px 22px', borderRadius: 8, fontWeight: 600,
    fontSize: 14, border: 'none', transition: 'opacity 0.2s', ...style
  }
  const variants = {
    primary: { background: '#0057A8', color: '#fff' },
    secondary: { background: '#e8f0fb', color: '#0057A8' },
    danger: { background: '#e53935', color: '#fff' },
  }
  return <button style={{ ...base, ...variants[variant] }} {...props}>{children}</button>
}
