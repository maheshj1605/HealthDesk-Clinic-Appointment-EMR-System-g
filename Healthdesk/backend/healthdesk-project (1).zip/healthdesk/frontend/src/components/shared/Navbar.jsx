import { useAuth } from '../../context/AuthContext'
import { useNavigate } from 'react-router-dom'
import { LogOut, Activity } from 'lucide-react'

export default function Navbar() {
  const { user, logout } = useAuth()
  const navigate = useNavigate()

  const handleLogout = () => { logout(); navigate('/login') }

  const roleColor = {
    PATIENT: 'bg-green-100 text-green-800',
    DOCTOR: 'bg-blue-100 text-blue-800',
    RECEPTIONIST: 'bg-purple-100 text-purple-800',
  }

  return (
    <nav className="bg-white shadow-sm border-b border-gray-200 px-6 py-3 flex items-center justify-between">
      <div className="flex items-center gap-2">
        <Activity className="text-blue-600" size={22} />
        <span className="font-bold text-gray-800 text-lg">HealthDesk</span>
      </div>
      <div className="flex items-center gap-3">
        <span className="text-sm text-gray-600">{user?.fullName}</span>
        <span className={`text-xs font-semibold px-2 py-1 rounded-full ${roleColor[user?.role] || ''}`}>
          {user?.role}
        </span>
        <button onClick={handleLogout} className="flex items-center gap-1 text-gray-500 hover:text-red-500 text-sm transition-colors">
          <LogOut size={16} /> Logout
        </button>
      </div>
    </nav>
  )
}
