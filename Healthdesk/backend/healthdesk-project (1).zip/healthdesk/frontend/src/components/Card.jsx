export default function Card({ children, style = {} }) {
  return (
    <div style={{
      background: '#fff', borderRadius: 12, padding: 24,
      boxShadow: '0 2px 12px rgba(0,87,168,0.08)',
      ...style
    }}>
      {children}
    </div>
  )
}
