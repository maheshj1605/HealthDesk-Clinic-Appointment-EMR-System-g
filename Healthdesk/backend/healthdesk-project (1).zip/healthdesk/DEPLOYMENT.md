# Deployment Guide — Railway + Vercel + PlanetScale

## 1. Database — PlanetScale (MySQL)

1. Go to https://planetscale.com → Create database `healthdesk`
2. Create a branch `main` → Get connection string
3. Copy the `DATABASE_URL` — format: `mysql://user:pass@host/healthdesk?ssl={"rejectUnauthorized":true}`

## 2. Backend — Railway

1. Go to https://railway.app → New Project → Deploy from GitHub
2. Select your `healthdesk/backend` folder
3. Set these environment variables in Railway dashboard:

```
DB_URL=jdbc:mysql://your-planetscale-host/healthdesk?useSSL=true&requireSSL=true
DB_USER=your-planetscale-user
DB_PASS=your-planetscale-password
JWT_SECRET=generate-with: openssl rand -base64 64
CORS_ORIGINS=https://your-app.vercel.app
PORT=8080
```

4. Railway auto-detects Maven and runs `mvn package` then `java -jar target/*.jar`
5. Note your Railway URL: `https://healthdesk-production.up.railway.app`

### Procfile (Railway uses this):
```
web: java -jar target/healthdesk-backend-1.0.0.jar
```

## 3. Frontend — Vercel

1. Go to https://vercel.com → New Project → Import from GitHub
2. Select `healthdesk/frontend` folder
3. Set environment variable:

```
VITE_API_URL=https://your-railway-url.up.railway.app/api
```

4. Build settings (auto-detected):
   - Build Command: `npm run build`
   - Output Directory: `dist`

5. Deploy → Get your Vercel URL

6. Go back to Railway and update `CORS_ORIGINS` with your Vercel URL.

## 4. GitHub Actions CI/CD

The `.github/workflows/ci.yml` file:
- Runs on every push to `main`
- Builds the backend with Maven
- Runs tests
- Railway auto-deploys on push to `main`

## Environment Summary

| Service | Purpose | Free Tier |
|---------|---------|-----------|
| PlanetScale | MySQL DB | 5GB, 1B row reads/month |
| Railway | Spring Boot API | 500hrs/month |
| Vercel | React Frontend | Unlimited |

## Quick Test After Deploy

```bash
# Test backend health
curl https://your-railway-url.up.railway.app/api/auth/login \
  -X POST -H "Content-Type: application/json" \
  -d '{"email":"test@test.com","password":"wrong"}' 
# Should return 401 (not 500 = DB is connected)

# Register a test user
curl https://your-railway-url.up.railway.app/api/auth/register \
  -X POST -H "Content-Type: application/json" \
  -d '{"email":"patient@test.com","password":"Test@123","fullName":"John Doe","role":"PATIENT"}'
```
