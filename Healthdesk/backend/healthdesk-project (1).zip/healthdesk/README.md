# HealthDesk — Clinic Appointment & EMR System

A full-stack clinic management system built with **Spring Boot + Spring Security + React + MySQL**.

## Features
- Patient registration & appointment booking
- Doctor schedule management
- Electronic Medical Records (EMR)
- Prescription PDF generation (iText)
- Role-based access: Doctor / Receptionist / Patient
- JWT authentication

## Tech Stack
| Layer      | Technology                                |
|------------|-------------------------------------------|
| Backend    | Java 17, Spring Boot 3.2, Spring Security |
| Auth       | JWT (jjwt 0.12.3)                         |
| Database   | MySQL 8, Spring Data JPA, HikariCP        |
| PDF        | iText 5.5.13                              |
| Frontend   | React 18, React Router, Axios             |
| Deploy     | Railway (backend) + Vercel (frontend) + PlanetScale (DB) |

## Project Structure
```
healthdesk/
├── backend/
│   ├── src/main/java/com/healthdesk/
│   │   ├── config/         # SecurityConfig, CORS
│   │   ├── controller/     # AuthController, AppointmentController, EMRController, UserController
│   │   ├── dto/            # AuthRequest, RegisterRequest, AppointmentRequest, EMRRequest
│   │   ├── model/          # User, Appointment, EMR, enums
│   │   ├── repository/     # JPA repositories with custom queries
│   │   ├── security/       # JwtUtil, JwtAuthFilter
│   │   └── service/        # AuthService, AppointmentService, EMRService, PrescriptionPdfService
│   └── pom.xml
├── frontend/
│   └── src/
│       ├── components/     # Navbar, Card, Button
│       ├── context/        # AuthContext
│       ├── pages/          # Login, Register, Dashboard, Appointments, EMR
│       └── services/       # api.js (Axios)
├── docker-compose.yml
└── README.md
```

## Local Development

### Prerequisites
- Java 17+, Maven 3.9+
- Node.js 20+
- MySQL 8 running locally

### Backend
```bash
cd backend
# Set env vars or edit application.properties
mvn spring-boot:run
# Runs on http://localhost:8080
```

### Frontend
```bash
cd frontend
npm install
npm run dev
# Runs on http://localhost:5173
```

### Docker (full stack)
```bash
docker-compose up --build
# Frontend: http://localhost:80
# Backend:  http://localhost:8080
```

## API Endpoints

| Method | Endpoint                          | Role        | Description            |
|--------|-----------------------------------|-------------|------------------------|
| POST   | /api/auth/register                | Public      | Register user          |
| POST   | /api/auth/login                   | Public      | Login, get JWT         |
| GET    | /api/doctors                      | Public      | List all doctors       |
| POST   | /api/appointments                 | PATIENT     | Book appointment       |
| GET    | /api/appointments/mine            | Any authed  | My appointments        |
| GET    | /api/appointments/all             | RECEPTIONIST| All appointments       |
| PUT    | /api/appointments/{id}/status     | DR/RECEP    | Update status          |
| POST   | /api/emr                          | DOCTOR      | Create EMR record      |
| GET    | /api/emr/patient/{id}             | DR/RECEP    | Get patient records    |
| GET    | /api/emr/{id}/pdf                 | All authed  | Download prescription  |
| GET    | /api/admin/patients               | RECEPTIONIST| List all patients      |

## Deploy to Railway + Vercel + PlanetScale

### 1. PlanetScale (Database)
- Create a free PlanetScale account at planetscale.com
- Create database `healthdesk`
- Copy connection string to Railway env vars

### 2. Railway (Backend)
- Connect your GitHub repo
- Set root directory to `backend/`
- Add environment variables:
  ```
  DATABASE_URL=jdbc:mysql://your-planetscale-url/healthdesk
  DB_USERNAME=your-username
  DB_PASSWORD=your-password
  JWT_SECRET=your-256-bit-secret
  CORS_ORIGINS=https://your-vercel-app.vercel.app
  ```

### 3. Vercel (Frontend)
- Connect GitHub repo, set root to `frontend/`
- Add env var: `VITE_API_URL=https://your-railway-app.railway.app`
- Update `vite.config.js` proxy target to Railway URL

## Resume Line
> Engineered a full-stack clinic management system using **Spring Boot + Spring Security + React** with role-based access for 3 user types (Doctor/Receptionist/Patient), EMR storage, automated prescription PDF generation, and sub-200ms API response time via MySQL index optimization. Deployed on **Railway + Vercel + PlanetScale**.
