package com.healthdesk.service;

import com.healthdesk.dto.EmrRequest;
import com.healthdesk.model.Appointment;
import com.healthdesk.model.EmrRecord;
import com.healthdesk.model.User;
import com.healthdesk.repository.AppointmentRepository;
import com.healthdesk.repository.EmrRepository;
import com.healthdesk.repository.UserRepository;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
@RequiredArgsConstructor
public class EmrService {

    private final EmrRepository emrRepository;
    private final UserRepository userRepository;
    private final AppointmentRepository appointmentRepository;

    public EmrRecord createRecord(EmrRequest request, Long doctorId) {
        User patient = userRepository.findById(request.getPatientId())
            .orElseThrow(() -> new RuntimeException("Patient not found"));
        User doctor = userRepository.findById(doctorId)
            .orElseThrow(() -> new RuntimeException("Doctor not found"));

        Appointment appointment = null;
        if (request.getAppointmentId() != null) {
            appointment = appointmentRepository.findById(request.getAppointmentId()).orElse(null);
            if (appointment != null) {
                appointment.setStatus(Appointment.Status.COMPLETED);
                appointmentRepository.save(appointment);
            }
        }

        EmrRecord record = EmrRecord.builder()
            .patient(patient)
            .doctor(doctor)
            .appointment(appointment)
            .diagnosis(request.getDiagnosis())
            .prescription(request.getPrescription())
            .symptoms(request.getSymptoms())
            .notes(request.getNotes())
            .labResults(request.getLabResults())
            .build();

        return emrRepository.save(record);
    }

    public List<EmrRecord> getPatientHistory(Long patientId) {
        User patient = userRepository.findById(patientId)
            .orElseThrow(() -> new RuntimeException("Patient not found"));
        return emrRepository.findByPatientOrderByVisitDateDesc(patient);
    }

    public byte[] generatePrescriptionPdf(Long emrId) throws DocumentException {
        EmrRecord record = emrRepository.findById(emrId)
            .orElseThrow(() -> new RuntimeException("EMR record not found"));

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        Document document = new Document(PageSize.A4);
        PdfWriter.getInstance(document, baos);
        document.open();

        // Fonts
        Font titleFont = new Font(Font.FontFamily.HELVETICA, 20, Font.BOLD, new BaseColor(0, 87, 168));
        Font headerFont = new Font(Font.FontFamily.HELVETICA, 13, Font.BOLD);
        Font normalFont = new Font(Font.FontFamily.HELVETICA, 11);
        Font labelFont = new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD, BaseColor.GRAY);

        // Header
        Paragraph title = new Paragraph("HealthDesk Clinic", titleFont);
        title.setAlignment(Element.ALIGN_CENTER);
        document.add(title);

        Paragraph subtitle = new Paragraph("Electronic Medical Prescription", normalFont);
        subtitle.setAlignment(Element.ALIGN_CENTER);
        subtitle.setSpacingAfter(10f);
        document.add(subtitle);

        // Divider line
        LineSeparator ls = new LineSeparator();
        ls.setLineColor(new BaseColor(0, 87, 168));
        document.add(new Chunk(ls));
        document.add(Chunk.NEWLINE);

        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd MMM yyyy");

        // Patient Info Table
        PdfPTable infoTable = new PdfPTable(2);
        infoTable.setWidthPercentage(100);
        infoTable.setSpacingAfter(15f);

        addTableCell(infoTable, "Patient Name", record.getPatient().getFullName(), labelFont, normalFont);
        addTableCell(infoTable, "Doctor", "Dr. " + record.getDoctor().getFullName(), labelFont, normalFont);
        addTableCell(infoTable, "Visit Date", record.getVisitDate().format(fmt), labelFont, normalFont);
        addTableCell(infoTable, "Patient Phone", record.getPatient().getPhone() != null ? record.getPatient().getPhone() : "-", labelFont, normalFont);
        document.add(infoTable);

        document.add(new Chunk(ls));
        document.add(Chunk.NEWLINE);

        // Symptoms
        if (record.getSymptoms() != null && !record.getSymptoms().isEmpty()) {
            document.add(new Paragraph("Symptoms", headerFont));
            document.add(new Paragraph(record.getSymptoms(), normalFont));
            document.add(Chunk.NEWLINE);
        }

        // Diagnosis
        document.add(new Paragraph("Diagnosis", headerFont));
        document.add(new Paragraph(record.getDiagnosis() != null ? record.getDiagnosis() : "-", normalFont));
        document.add(Chunk.NEWLINE);

        // Prescription
        document.add(new Paragraph("Prescription / Medications", headerFont));
        document.add(new Paragraph(record.getPrescription() != null ? record.getPrescription() : "-", normalFont));
        document.add(Chunk.NEWLINE);

        // Lab Results
        if (record.getLabResults() != null && !record.getLabResults().isEmpty()) {
            document.add(new Paragraph("Lab Results", headerFont));
            document.add(new Paragraph(record.getLabResults(), normalFont));
            document.add(Chunk.NEWLINE);
        }

        // Notes
        if (record.getNotes() != null && !record.getNotes().isEmpty()) {
            document.add(new Paragraph("Doctor Notes", headerFont));
            document.add(new Paragraph(record.getNotes(), normalFont));
            document.add(Chunk.NEWLINE);
        }

        // Footer
        document.add(new Chunk(ls));
        Paragraph footer = new Paragraph("Generated by HealthDesk — " +
            java.time.LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd MMM yyyy HH:mm")),
            new Font(Font.FontFamily.HELVETICA, 9, Font.ITALIC, BaseColor.GRAY));
        footer.setAlignment(Element.ALIGN_RIGHT);
        document.add(footer);

        document.close();
        return baos.toByteArray();
    }

    private void addTableCell(PdfPTable table, String label, String value, Font labelFont, Font valueFont) {
        PdfPCell labelCell = new PdfPCell(new Phrase(label, labelFont));
        labelCell.setBorder(Rectangle.NO_BORDER);
        labelCell.setPadding(4f);
        table.addCell(labelCell);

        PdfPCell valueCell = new PdfPCell(new Phrase(value, valueFont));
        valueCell.setBorder(Rectangle.NO_BORDER);
        valueCell.setPadding(4f);
        table.addCell(valueCell);
    }
}
