package com.healthdesk.repository;

import com.healthdesk.model.EmrRecord;
import com.healthdesk.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EmrRepository extends JpaRepository<EmrRecord, Long> {
    List<EmrRecord> findByPatientOrderByVisitDateDesc(User patient);
    List<EmrRecord> findByDoctorOrderByVisitDateDesc(User doctor);
}
