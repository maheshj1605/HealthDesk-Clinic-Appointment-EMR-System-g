package com.healthdesk.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class EMRRequest {
    @NotNull private Long patientId;
    @NotNull private Long appointmentId;
    private String diagnosis;
    private String prescription;
    private String notes;
}
