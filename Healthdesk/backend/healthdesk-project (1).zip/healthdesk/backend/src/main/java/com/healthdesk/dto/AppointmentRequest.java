package com.healthdesk.dto;

import jakarta.validation.constraints.*;
import lombok.Data;
import java.time.LocalDateTime;

@Data
public class AppointmentRequest {
    @NotNull private Long doctorId;
    @NotNull private LocalDateTime appointmentTime;
    private String notes;
}
