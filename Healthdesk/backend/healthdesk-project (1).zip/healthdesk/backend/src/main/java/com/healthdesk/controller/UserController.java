package com.healthdesk.controller;

import com.healthdesk.model.*;
import com.healthdesk.repository.UserRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api")
public class UserController {

    private final UserRepository userRepo;

    public UserController(UserRepository userRepo) {
        this.userRepo = userRepo;
    }

    @GetMapping("/doctors")
    public ResponseEntity<List<User>> getDoctors() {
        List<User> doctors = userRepo.findByRole(Role.DOCTOR);
        // Don't expose passwords
        doctors.forEach(d -> d.setPassword(null));
        return ResponseEntity.ok(doctors);
    }

    @GetMapping("/admin/patients")
    public ResponseEntity<List<User>> getPatients() {
        List<User> patients = userRepo.findByRole(Role.PATIENT);
        patients.forEach(p -> p.setPassword(null));
        return ResponseEntity.ok(patients);
    }
}
