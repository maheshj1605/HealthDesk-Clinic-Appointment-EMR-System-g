package com.healthdesk.dto;
import lombok.Data;
@Data
public class EmrRequest {
    private Long patientId;
    private Long appointmentId;
    private String diagnosis;
    private String prescription;
    private String symptoms;
    private String notes;
    private String labResults;
}
