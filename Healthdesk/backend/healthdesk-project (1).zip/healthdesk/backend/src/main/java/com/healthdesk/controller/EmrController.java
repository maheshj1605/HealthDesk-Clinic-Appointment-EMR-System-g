package com.healthdesk.controller;

import com.healthdesk.dto.EmrRequest;
import com.healthdesk.model.EmrRecord;
import com.healthdesk.model.User;
import com.healthdesk.repository.UserRepository;
import com.healthdesk.service.EmrService;
import com.itextpdf.text.DocumentException;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/emr")
@RequiredArgsConstructor
public class EmrController {

    private final EmrService emrService;
    private final UserRepository userRepository;

    @PostMapping
    @PreAuthorize("hasRole('DOCTOR')")
    public ResponseEntity<EmrRecord> createRecord(@RequestBody EmrRequest request,
                                                   @AuthenticationPrincipal UserDetails userDetails) {
        User doctor = userRepository.findByEmail(userDetails.getUsername()).orElseThrow();
        return ResponseEntity.ok(emrService.createRecord(request, doctor.getId()));
    }

    @GetMapping("/patient/{patientId}")
    @PreAuthorize("hasAnyRole('DOCTOR','RECEPTIONIST','PATIENT')")
    public ResponseEntity<List<EmrRecord>> getHistory(@PathVariable Long patientId) {
        return ResponseEntity.ok(emrService.getPatientHistory(patientId));
    }

    @GetMapping("/{emrId}/pdf")
    public ResponseEntity<byte[]> downloadPdf(@PathVariable Long emrId) throws DocumentException {
        byte[] pdf = emrService.generatePrescriptionPdf(emrId);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=prescription-" + emrId + ".pdf")
                .contentType(MediaType.APPLICATION_PDF)
                .body(pdf);
    }
}
